function [ ang_rad ] = deg2rad( ang_deg )
%RAD2DEG convert from radians to degrees
%   TCS 10/20/14 - missing in this version of matlab?

ang_rad = 2*pi*ang_deg/(360);


end

