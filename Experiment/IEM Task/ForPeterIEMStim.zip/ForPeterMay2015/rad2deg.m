function [ ang_deg ] = rad2deg( ang_rad )
%RAD2DEG convert from radians to degrees
%   TCS 10/20/14 - missing in this version of matlab?

ang_deg = 360*ang_rad/(2*pi);


end

