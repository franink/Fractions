%a short script to make sure no button down on the mouse

buttons = 1;    
    

while sum(buttons) > 0
    [x y buttons] = GetMouse;
end